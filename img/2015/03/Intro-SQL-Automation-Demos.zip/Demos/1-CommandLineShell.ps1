﻿### Initial setup helpful commands

### Useful cmdlets

# Get command cmdlet
Get-Command 
Show-Command

# Get help cmdlet
Get-Help 

# Get the latest help files from the internet
Update-Help 

# Get the members and properties of an object
[int]$NewVariable | Get-Member 



# Set Execution Policy so you can run scripts
Get-ExecutionPolicy
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned

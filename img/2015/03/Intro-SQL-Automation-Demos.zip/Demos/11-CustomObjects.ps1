### Custom Object

# The Raw Variables
$LastName = "Sommer"
$FirstName = "Chris"
$EmailAddress = "cjsommer@gmail.com"

# Create a custom object using the add-member method
$MyPerson1 = New-Object psobject
$MyPerson1 | Add-Member noteproperty LastName ($LastName)
$MyPerson1 | Add-Member noteproperty FirstName ($FirstName)
$MyPerson1 | Add-Member noteproperty EmailAddress ($EmailAddress)

$MyPerson1

# Create a custom object using a properties hash table
$MyPerson2Properties = @{
    "LastName" = $LastName ;
    "FirstName" = $FirstName ;
    "EmailAddress" = $EmailAddress
}

$MyPerson2 = New-Object -TypeName PSObject -Property $MyPerson2Properties

$MyPerson2
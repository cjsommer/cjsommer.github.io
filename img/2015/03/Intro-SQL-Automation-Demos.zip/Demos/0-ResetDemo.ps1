﻿<#
cd "C:\Users\BIGRED-7\Documents\Git\intro-posh-sql-automation"

# Recopy all backup files from INST1 to INST2 Restore Location

$BackupsINST1 = 'C:\SQL\MSSQL11.INST1\MSSQL\Backup\BIGRED-7-PC$INST1\AdventureWorks2012'
$RestoreINST2 = 'C:\SQL\MSSQL11.INST2\MSSQL\Backup\Restore\AdventureWorks2012'

if (Test-Path -Path $RestoreINST2 -Type Container) {
    Remove-Item $RestoreINST2 -Recurse -Force
    New-Item -Path $RestoreINST2 -ItemType Directory
}

Get-ChildItem $BackupsINST1 -File -Recurse | Copy-Item -Destination $RestoreINST2

#>

# Cleanup the AdventureWorks2012 script location
Remove-Item "C:\SQL\Working\AdventureWorks2012\*" -Force

# Remove the AdventureWorks2012 db from INST2
cd "C:\Users\BIGRED-7\Documents\Git\intro-posh-sql-automation"
Push-Location; Import-Module SQLPS -DisableNameChecking; Pop-Location
.\SQLServerMgmt\Start-SQLServices.ps1

$DropDBSQL = "IF EXISTS (SELECT name FROM sys.databases WHERE name = 'AdventureWorks2012') DROP DATABASE [AdventureWorks2012];"
Invoke-Sqlcmd -ServerInstance "localhost\inst2" -Database "master" -Query $DropDBSQL

Remove-Module SQLPS
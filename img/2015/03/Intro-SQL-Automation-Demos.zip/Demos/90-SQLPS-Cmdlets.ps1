# SQLPS Cmdlets
Push-Location; Import-Module SQLPS -DisableNameChecking; Pop-Location

# Examples
$SQLServer = "localhost\inst1"
$Database = "master"
$Query = "SELECT @@SERVERNAME AS [ServerName]"

# Invoke-Sqlcmd
Invoke-Sqlcmd -ServerInstance $SQLServer -Database $Database -Query $Query

# Backup-SqlDatabase to the default backup location. Vanilla naming standard (dbname.log)
# Backup-SqlDatabase -ServerInstance $SQLServer -Database $Database -BackupAction Log

# Restore-SqlDatabase Example

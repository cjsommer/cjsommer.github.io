### Modules

# Get currently loaded modules
Get-Module

# Get availabile modules
Get-Module -ListAvailable

# Load a module
Import-Module SQLPS
cd "C:\Users\BIGRED-7\Documents\Git\intro-posh-sql-automation"
Remove-Module SQLPS

Push-Location; Import-Module SQLPS -DisableNameChecking; Pop-Location

# Get commands that come with a specific module
Get-Command -Module SQLPS


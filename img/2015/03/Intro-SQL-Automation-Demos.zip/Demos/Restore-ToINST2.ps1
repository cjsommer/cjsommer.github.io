<#
.NOTES
 Author: Chris Sommer
 Modifications:
    2014-12-04 - Initial Script Creation

.SYNOPSIS
 Restore a database to INST2

.DESCRIPTION
 Restore a database onto INST2 using the FULL and TLOG backups
 Assumptions: 
 Backup files will be staged to "DefaultBackupLocation\Restore\DatabaseName" on target server
 Only written for FULL and TLOG backups

 .PARAMETER TargetSQLServer
 Name of the SQL Server to do the restore on

 .PARAMETER DBName
 Name of the database to restore

 .PARAMETER PointInTime
 Point in time to do the restore to

 .PARAMETER WhatIf
 If WhatIf is set to true do not restore the database

#>
Param(
    [string]$TargetSQLServer = "localhost\inst2" ,
    [string]$DBName = "AdventureWorks2012" ,
    [datetime]$PointInTime = "2015-03-15 19:00:00" ,
    [bool]$WhatIf = $false
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$Error.Clear()

$Invocation = (Get-Variable MyInvocation).Value
$ScriptName = $Invocation.MyCommand.Name
$ScriptLocation = Split-Path $Invocation.MyCommand.Path

$ComputerName = $env:COMPUTERNAME
$UserName = $env:USERNAME

### Functions
function Get-SQLLocations
{
    param( [string]$SQLServer )
    $ServerInfo = New-Object Microsoft.SqlServer.Management.Smo.Server $SQLServer
    $ServerInfo.ConnectionContext.Connect()
    $ServerInfo | Select-Object Name,NetName,InstanceName,DefaultFile,DefaultLog,BackupDirectory
}

function Get-RelocateFileArray
{
    param (
        [string]$SQLServer ,
        [string]$BackupFile ,
        [string]$NewDataLoc ,
        [string]$NewLogLoc 
    )
    $FilelistSQL = "RESTORE FILELISTONLY FROM DISK = '${BackupFile}';"
    $Filelist = Invoke-Sqlcmd -ServerInstance $SQLServer -Database "master" -Query $FilelistSQL
    [array]$ReturnResult = $null
    
    foreach ($File in $Filelist) {
        Switch ($File.Type){
            "D" {
                $FileName = ($File.PhysicalName).split("\")[((($File.PhysicalName).Split("\")).Count)-1]
                $ReturnResult += New-Object Microsoft.SqlServer.Management.Smo.RelocateFile($File.LogicalName,"${NewDataLoc}\${FileName}")
            }
            "L" {
                $FileName = ($File.PhysicalName).split("\")[((($File.PhysicalName).Split("\")).Count)-1]
                $ReturnResult += New-Object Microsoft.SqlServer.Management.Smo.RelocateFile($File.LogicalName,"${NewLogLoc}\${FileName}")
            }
        }
    }
    $ReturnResult
}

### Main Program Body
try {
    Clear-Host
    Push-Location; Import-Module SQLPS -DisableNameChecking ; Pop-Location

    # Get the default file locations from the SQLServer
    $TargetServerLocations = Get-SQLLocations -SQLServer $TargetSQLServer
    $BackupFileLocation = $TargetServerLocations.BackupDirectory + "\Restore\$DBName"

    # Restore the full backup
    $FullBkup = Get-ChildItem -Path $BackupFileLocation -Filter *.bak | 
        Where-Object LastWriteTime -le $PointInTime |
        Sort-Object LastWriteTime -Descending | 
        Select-Object -First 1

    $RelocateArray = Get-RelocateFileArray -SQLServer $TargetSQLServer -BackupFile $FullBkup.FullName `
        -NewDataLoc $TargetServerLocations.DefaultFile -NewLogLoc $TargetServerLocations.DefaultLog

    Write-Output ("Restoring [$DBName] from full backup '$FullBkup'")
    if (!$WhatIf) {
        Restore-SqlDatabase -ServerInstance $TargetSQLServer -Database $DBName -BackupFile $FullBkup.FullName `
             -RelocateFile $RelocateArray -Replace -NoRecovery
    }

    # Restore all of the logs
    $LogBkups = Get-ChildItem -Path $BackupFileLocation -Filter *.trn | 
        Where-Object { $_.LastWriteTime -le $PointInTime -and $_.LastWriteTime -gt $FullBkup.LastWriteTime } |
        Sort-Object LastWriteTime 

    foreach ($LogBkup in $LogBkups) {
        Write-Output ("Restoring log backup '$LogBkup'")
        if (!$WhatIf) {
            Restore-SqlDatabase -ServerInstance $TargetSQLServer -Database $DBName -BackupFile $LogBkup.FullName -NoRecovery
        }
    }
    if (!$WhatIf) {
        Invoke-Sqlcmd -ServerInstance $TargetSQLServer -Database "master" -Query "RESTORE DATABASE [$DBName] WITH RECOVERY ;"
    }

} catch {
    $Error
} finally {
    Write-Output("We're done!")
}

### Functions

# Simple Function
function Add-Numbers 
{
    param ( 
        $Num1,
        $Num2
    )
    $Num1 + $Num2
}

Add-Numbers -Num1 3 -Num2 7

### Broken function because of erroneous output
function Add-Numbers-Broken
{
    param (
        $Num1,
        $Num2
    )
    Write-Output ("Old school debug statement! Don't do this in PowerShell!")
    $Num1 + $Num2
}

Add-Numbers-Broken -Num1 3 -Num2 7



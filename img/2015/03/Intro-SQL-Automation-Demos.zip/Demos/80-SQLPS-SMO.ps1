# SMO
Push-Location; Import-Module SQLPS -DisableNameChecking; Pop-Location

# Microsoft.SqlServer.Management.Smo.Server
$SqlServerName = "localhost\inst1"
$SrvObject = New-Object 'Microsoft.SqlServer.Management.Smo.Server' $SQLServerName
$SrvObject.ConnectionContext.Connect()

# SMO Object Members
$SrvObject | Get-Member

# All properties of the SQL Server SMO Object
$SrvObject | Format-List
$SrvObject.Properties | Select-Object Name, Value, Readable, Writable, Expensive, Enabled | Format-Table -AutoSize

# Grab a few SMO Object properties
$SrvObject | Select-Object -Property BackupDirectory,DefaultFile,DefaultLog
$SrvObject | Select-Object BackupDirectory,DefaultFile,DefaultLog


# Interactive drill into JobServer.Jobs
$SrvObject.JobServer.Jobs | Format-List

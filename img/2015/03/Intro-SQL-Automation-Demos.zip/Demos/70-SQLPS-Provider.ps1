# SQLSERVER Provider
Push-Location; Import-Module SQLPS -DisableNameChecking; Pop-Location

# Walking the SQL tree
cd SQLSERVER:\

# Script a single table
cd SQLSERVER:\SQL\BIGRED-7-PC\INST1\Databases\AdventureWorks2012\Tables
$mytable = Get-ChildItem . | Where-Object {$_.Schema -eq "Sales" -and $_.Name -eq "store"} 
$mytable | Get-Member
$mytable.Script()


# Script all of the database tables for AdventureWorks2012 using the SQL Provider
$SQLProviderPath = "SQLSERVER:\SQL\BIGRED-7-PC\INST1\Databases\AdventureWorks2012\Tables"
$OutputPath = "C:\SQL\Working\AdventureWorks2012"
Get-ChildItem $OutputPath | Remove-Item
Get-ChildItem $OutputPath 

ForEach($table in (Get-ChildItem $SQLProviderPath)) {
    $schemaname = $table.Schema
    $tablename = $table.Name
    $table.Script() | Add-Content "$OutputPath\$schemaname.$tablename.sql"
}

Get-ChildItem $OutputPath
﻿### Variables

### PowerShell Data Types
[string]    # Fixed-length string of Unicode characters
[char]      # A Unicode 16-bit character
[byte]      # An 8-bit unsigned character

[int]       # 32-bit signed integer
[long]      # 64-bit signed integer
[bool]      # Boolean True/False value

[decimal]   # A 128-bit decimal value
[single]    # Single-precision 32-bit floating point number
[double]    # Double-precision 64-bit floating point number
[DateTime]  # Date and Time

[xml]       # Xml object
[array]     # An array of values
[hashtable] # Hashtable object

### Declaring Variables
$MyNumber1 = 101
$MyNumber2 = 2.23456
$MyNumber1
$MyNumber2

$MyName = "Chris Sommer"
$MyName

[array]$MyArray = ("rochester","buffalo","syracuse")
$MyArray

### Using Cmdlet Output and Variables (objects)
$Files = Get-ChildItem "C:\SQL\MSSQL11.INST2\MSSQL\Backup\Restore\AdventureWorks2012"

$Files | Get-Member

$Files | Select-Object -Property FullName

$Files | Where-Object LastWriteTime -gt "2015-03-15 00:00:00" | Sort-Object LastWriteTime

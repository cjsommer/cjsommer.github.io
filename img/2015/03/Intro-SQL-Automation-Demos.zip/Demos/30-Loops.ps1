﻿### Loops

# Each loop will count to the number 5 and exit
Clear-Host

# while loop
Write-Output ("While Loop Example")
$Counter = 1
While ($Counter -le 5)
{
    Write-Output ("My counter is now: $Counter")
    $Counter ++
}

# do while loop
Write-Output ("`nDo While Loop Example")
$Counter = 1
do {
    Write-Output ("My counter is now: $Counter")
    $Counter ++    
} while ($Counter -le 5)

# do until loop example
Write-Output ("`nDo Until Loop Example")
$Counter = 1
do {
    Write-Output ("My counter is now: $Counter")
    $Counter ++    
} until ($Counter -gt 5)

# for loop
Write-Output ("`nFor Loop Example")
for ($Counter = 1; $Counter -le 5; $Counter++) {
    Write-Output ("My counter is now: $Counter")
}

# foreach loop example
Write-Output ("`nForeach Loop Example")
foreach ($Counter in 1..5) {
    Write-Output ("My counter is now: $Counter")
}

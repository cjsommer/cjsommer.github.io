﻿<### Conditional operators
-eq       # Equals
-ne       # Not Equals
-gt       # Greater than
-ge       # Greater than or equal
-lt       # Less than
-le       # Less than or equal

-like -notlike         # Wildcards *
-match -notmatch       # Regular expressions
-contains -notcontains # Search a collection (array)

-and -or  # Compound conditionals
#>

### If statement comparing our variables
$var1 = 111
$var2 = 11

if ($var1 -eq $var2) {
    Write-Output ("$var1 equals $var2")
} elseif ($var1 -lt $var2) {
    Write-Output ("$var1 is less than $var2")
} elseif ($var1 -gt $var2) {
  Write-Output ("$var1 is greater than $var2")
} 

### Regular expression matching -match
$str1 = "The cow jumped over the moon"
if ($str1 -match "^The cow") {
    Write-Output ("It's in there!")
} else {
    Write-Output ("Sorry charlie!")
}

### An example for arrays -contains
$arr1 = @("rochester","buffalo","syracuse")
if ($arr1 -contains "rochester") {
    Write-Output ("It's in there!")
} else {
    Write-Output ("Sorry charlie!")
}

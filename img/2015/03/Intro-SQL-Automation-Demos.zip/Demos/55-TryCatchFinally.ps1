﻿### Try/Catch/Finally

# Error Handling
Clear-Host
$Error.Clear()

$ErrorActionPreference = "Continue"
#$ErrorActionPreference = "SilentlyContinue"
#$ErrorActionPreference = "Stop"

"ErrorActionPreference: $ErrorActionPreference"

try { 
    # All terminating errors will fall into the catch block
    Write-Output ("### Begin Try!")
    Get-ChildItem "C:\bogusdirectory\bogusfile.txt" # -ErrorAction Stop
    # 1/0
    Write-Output ("### End Try!")
} catch {
    Write-Output ("### Catch!")
    $error[0]
} finally {
    Write-Output ("### Finally!")
}

### Error Handling
Clear-Host

### Clearing the error buffer
$Error.Clear()
$Error | Get-Member

# Continue
$ErrorActionPreference = "Continue" # Default
Get-ChildItem "C:\bogusdirectory\bogusfile.txt"
Write-Host "Past the error!"

# SilentlyContinue
$ErrorActionPreference = "SilentlyContinue"
Get-ChildItem "C:\bogusdirectory\bogusfile.txt"
Write-Host "Past the error!"

# Stop
$ErrorActionPreference = "Stop"
Get-ChildItem "C:\bogusdirectory\bogusfile.txt"
Write-Host "Past the error!"

# Inquire
$ErrorActionPreference = "Inquire" 
Get-ChildItem "C:\bogusdirectory\bogusfile.txt"
Write-Host "Past the error!"

# Continue at the script level, but Stop at the cmdlet level
$ErrorActionPreference = "Continue" # Default
Get-ChildItem "C:\bogusdirectory\bogusfile.txt" -ErrorAction Stop
Write-Host "Past the error!"